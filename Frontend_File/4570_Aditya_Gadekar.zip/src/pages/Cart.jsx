/* eslint-disable no-unused-vars */
import CartItemCard from "../components/CardItem";
import NavbarComponent from "../components/Header";
import React, { useState,  } from "react";

function Cart() {
  const [searchQuery, setSearchQuery] = useState(""); // Search query state


  return (
      <React.Fragment > 
      <NavbarComponent setSearchQuery={setSearchQuery} />
      <h3 className="text-xl font-semibold mb-2">Cart</h3>
      <CartItemCard/>
    </React.Fragment>
  );
}

export default Cart