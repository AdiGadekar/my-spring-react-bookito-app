import NavbarComponent from "../components/Header";
import ProductCard from "../components/ProductCard";
import React, { useState,  } from "react";

function Todos() {
  const [searchQuery, setSearchQuery] = useState(""); // Search query state


  return (
    <React.Fragment > 
      <><NavbarComponent setSearchQuery={setSearchQuery} /><ProductCard searchVal={searchQuery} /></>
    </React.Fragment>
  );
}

export default Todos;
