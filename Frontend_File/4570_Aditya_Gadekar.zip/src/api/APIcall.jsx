import { useState, useEffect } from "react";
import axios from "axios";

const useFetchTodos = ({url}) => {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const storedTodos = localStorage.getItem("todos");
    if (storedTodos) {
      setTodos(JSON.parse(storedTodos));  
      setLoading(false);
      return; 
    }

    const fetchTodos = async () => {
      try {
        const response = await axios.get(url);
        setTodos(response.data); 
        localStorage.setItem("todos", JSON.stringify(response.data)); 
        console.log("First 10 todos fetched and saved to localStorage.");
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchTodos();
  }, []); 

  return { todos, loading, error };
};

export default useFetchTodos;
