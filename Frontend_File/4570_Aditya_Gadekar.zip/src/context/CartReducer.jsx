// export const ADD_TO_CART = "ADD_TO_CART";
// export const REMOVE_FROM_CART = "REMOVE_FROM_CART";
// export const CLEAR_CART = "CLEAR_CART";

// const cartReducer = (state, action) => {

//   switch (action.type) {
//     case ADD_TO_CART:
//       { const existingProductIndex = state.items.findIndex(
//         (item) => item.id === action.payload.id
//       );
//       if (existingProductIndex !== -1) {
//         const updatedItems = [...state.items];
//         updatedItems[existingProductIndex].quantity += 1;
//         return {
//           ...state,
//           items: updatedItems,
//           total: updatedItems.reduce(
//             (total, item) => total + item.price * item.quantity,
//             0
//           ),
//         };
//       } else {
//         const updatedItems = [
//           ...state.items,
//           { ...action.payload, quantity: 1 },
//         ];
//         return {
//           ...state,
//           items: updatedItems,
//           total: updatedItems.reduce(
//             (total, item) => total + item.price * item.quantity,
//             0
//           ),
//         };
//       } }

//     case REMOVE_FROM_CART:
//       { const filteredItems = state.items.filter(
//         (item) => item.id !== action.payload.id
//       );
//       return {
//         ...state,
//         items: filteredItems,
//         total: filteredItems.reduce(
//           (total, item) => total + item.price * item.quantity,
//           0
//         ),
//       }; }

//     case CLEAR_CART:
//       return {
//         ...state,
//         items: [],
//         total: 0,
//       };

//     default:
//       return state;
//   }
// };
