/* eslint-disable no-undef */
/* eslint-disable react/prop-types */
import { createContext ,useReducer} from "react";
import {useCookies} from "react-cookie"
const AuthContext = createContext()

const authReducer  = (state,action) => {
    switch (action.type) {
        case"LOGIN":
        return {...state,isAuthin: true};
        case"LOGOUT":
        return {...state,isAuthin: false};
        default:
            return state;
    }
};

export const AuthProvider = ({children})=>{
    const[state,dispatch] = useReducer(authReducer, {
        isAuthin: false
    });
    const[cookies,setCookies,removeCookies] = useCookies(["authToken"])

    const login = () => {
        setCookies("authToken","dummy_token",
            {path:"/",maxAge:3600}
        );
        dispatch({type:"LOGIN"});
    };

    const logout = () => {
        removeCookies("authToken");
        dispatch({type:"LOGOUT"});
    };

    const isAuthin = !!cookies.authToken;


    return (
        <AuthContext.Provider value={{state,login,logout,isAuthin}}>
            {children}
        </AuthContext.Provider>
    );
};
export default AuthContext;