import { useContext } from 'react'
import {Navigate} from 'react-router-dom'
import AuthContext from '../context/AuthContext';

// eslint-disable-next-line react/prop-types
function ProtectedRoute({children}) {
    const {isAuthin} = useContext(AuthContext);

  return isAuthin? children: <Navigate to="/login"/>
};

export default ProtectedRoute