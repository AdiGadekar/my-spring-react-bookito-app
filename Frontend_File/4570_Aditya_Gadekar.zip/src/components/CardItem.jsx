/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useContext, useState } from "react";
import { ToastContainer } from "react-toastify";
import CartContext from "../context/CartContext";

function CartItemCard() {
  const [todos, setTodos] = useState([]);

  const state = JSON.parse(localStorage.getItem("cart"));
  
  state.items.forEach((element) => {
    console.log("Ele", element)
    if(element.price > 0){
        todos.push(element);
    }else{
        console.log("No")
    }
  });

  console.log(todos);
  const {  removeFromCart } = useContext(CartContext);


  const toggleRemoveFromCart = (product) => {
    if (product && product.id && product.price && product.title) {
      console.log("Removing", product);
      removeFromCart({ product });
    } else {
      console.error("Invalid product data:", product);
    }
  };

  return (
    <React.Fragment>
      <div className="m-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {todos.map((todo) => (
          <div
            style={{ backgroundColor: "#8c8e8d" }}
            key={todo.id}
            className="bg-white p-4 rounded-lg shadow-lg"
          >
            {console.log(todo.id)}
            <img src={todo.image} alt="card-image" />
            <h3 className="text-xl font-semibold mb-2">{todo.title}</h3>
            <hr />
            <h4 className="text-xl font-semibold mb-2">${todo.price}</h4>
            <p className="text-xl mb-2">{todo.description}</p>

            <div className="mt-4">

              <button
                onClick={() => toggleRemoveFromCart(todo)}
                className="bg-gray-400 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 m-2"
              >
                Remove From Cart
              </button>
            </div>
          </div>
        ))}
      </div>

      <ToastContainer />
    </React.Fragment>
  );
}

export default CartItemCard;
