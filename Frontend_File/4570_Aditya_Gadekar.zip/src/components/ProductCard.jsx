/* eslint-disable react/prop-types */
import React, { useContext, useState, useEffect } from "react";
import useFetchTodos from "../api/APIcall";
import { ToastContainer } from "react-toastify";
import CartContext from "../context/CartContext";

function ProductCard({ searchQueryValue }) {
  const searchQuery = searchQueryValue || "";
  const [todos, setTodos] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const todosPerPage = 6;

  const { todos: fetchedTodos } = useFetchTodos("https://fakestoreapi.com/products?_limit=10");

  useEffect(() => {
    setTodos(fetchedTodos || []);
  }, [fetchedTodos]);

  const filteredTodos = todos.filter((todo) =>
    todo.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentTodos = filteredTodos.slice(
    (currentPage - 1) * todosPerPage,
    currentPage * todosPerPage
  );
  const totalPages = Math.ceil(filteredTodos.length / todosPerPage);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const { addToCart,removeFromCart } = useContext(CartContext);

  const toggleAddToCart = (product) => {
    if (product && product.id && product.price && product.title) {
      console.log("Adding product to cart:", product);
      addToCart({ product });
    } else {
      console.error("Invalid product data:", product);
    }
  };

  const toggleRemoveFromCart = (product) => {
    if (product && product.id && product.price && product.title) {
      console.log("Removing", product);
      removeFromCart({ product });
    } else {
      console.error("Invalid product data:", product);
    }
  };

  return (
    <React.Fragment>
      <div className="m-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentTodos.map((todo) => (
          <div style={{ backgroundColor: '#8c8e8d' }} key={todo.id} className="bg-white p-4 rounded-lg shadow-lg">
            <img src={todo.image} alt="card-image" />
            <h3 className="text-xl font-semibold mb-2">{todo.title}</h3>
            <hr />
            <h4 className="text-xl font-semibold mb-2">${todo.price}</h4>
            <p className="text-xl mb-2">{todo.description}</p>

            <div className="mt-4">
              <button
                onClick={() => toggleAddToCart(todo)} 
                className="bg-gray-400 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 m-2"
              >
                Add to Cart
              </button>

              <button
                onClick={() => toggleRemoveFromCart(todo)} 
                className="bg-gray-400 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 m-2"
              >
                Remove From Cart
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-6">
        <nav>
          <ul className="inline-flex items-center space-x-2">
            <li>
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-l-lg disabled:bg-gray-400"
              >
                Prev
              </button>
            </li>
            {[...Array(totalPages)].map((_, index) => (
              <li key={index}>
                <button
                  onClick={() => paginate(index + 1)}
                  className={`px-4 py-2 text-sm font-medium ${
                    currentPage === index + 1
                      ? "bg-blue-500 text-white"
                      : "bg-white text-blue-500 border"
                  } rounded-md hover:bg-blue-100`}
                >
                  {index + 1}
                </button>
              </li>
            ))}
            <li>
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-r-lg disabled:bg-gray-400"
              >
                Next
              </button>
            </li>
          </ul>
        </nav>
      </div>

      <ToastContainer />
    </React.Fragment>
  );
}

export default ProductCard;
